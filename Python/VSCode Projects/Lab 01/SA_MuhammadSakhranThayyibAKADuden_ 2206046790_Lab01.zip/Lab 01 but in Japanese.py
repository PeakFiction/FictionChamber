print()
print("FARELの給料電卓へようこそ")
print("-------------------------------------")
showtime = int (input("どのくらい時間は彼が演ずりましたか？(時間で）"))
staytime = int (input("ホテルで、幾つ日は彼が住みましたか？"))
revenueshowraw = (showtime*300)
revenueshowtax = (revenueshowraw - (revenueshowraw*(1/10)))
disposableincome = (revenueshowtax - (staytime*50))
idrconv = (disposableincome * 14888)

print("Farelが", showtime, "時間で演ずりました. そうして", staytime, "日で住みました。彼の給料は税金と宿泊室の後で", disposableincome, "そうして、ルピアで", idrconv)

