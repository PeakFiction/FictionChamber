print()
print("FAREL'S SALARY CALCULATOR へようこそ")
print("-------------------------------------")
showtime = int (input("How many hours did Farel show?"))
staytime = int (input("How many days did Farel stay?"))
revenueshowraw = (showtime*300)
revenueshowtax = (revenueshowraw - (revenueshowraw*(1/10)))
disposableincome = (revenueshowtax - (staytime*50))
idrconv = (disposableincome * 14888)

print("Farel has performed for", showtime, "and stayed for", staytime, "he has generated", \
    disposableincome, "USD after tax and staying fees. Or, Rp.", idrconv)

